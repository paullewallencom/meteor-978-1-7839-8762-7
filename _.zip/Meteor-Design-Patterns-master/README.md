## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/meteor-design-patterns/9781783987627)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1783987626).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

#Meteor Design Patterns
Supporting material for [Meteor Design Patterns] (https://www.packtpub.com/web-development/meteor-design-patterns?utm_source=github&utm_medium=repository&utm_campaign=9781783987627) (Packt Publishing).

This is the code repository for Developing MicrIn order to follow this book, we are going to need to install Meteor version 1.1.0.2 or above and a Unix system such as a Mac or Linux computer 

##Related books

[Getting Started with Meteor.js JavaScript Framework] (https://www.packtpub.com/web-development/getting-started-meteorjs-javascript-framework?utm_source=github&utm_medium=repository&utm_campaign=9781782160823)
